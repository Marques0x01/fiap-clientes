import { handler } from "../index"

describe("CreateClientService", () => {

    it("Test", async () => {
        return true

    });
});
